package com.example.app;

import com.example.entity.Citizen;
import com.example.entity.Passport;
import com.example.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class App {
    public static void main(String[] args) {
        Citizen citizen = new Citizen();
        citizen.setId(1);
        citizen.setName("Harsha");

        Passport passport = new Passport();
        passport.setPassportNumber(12345);

        citizen.setPassport(passport);

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        session.persist(citizen);
        tx.commit();

        System.out.println("Citizen and Passport saved.");
        session.close();
    }
}

