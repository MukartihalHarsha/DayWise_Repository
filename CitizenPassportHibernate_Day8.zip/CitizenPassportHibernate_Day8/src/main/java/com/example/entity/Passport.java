package com.example.entity;

import jakarta.persistence.*;

@Entity
public class Passport {
    @Id
    private int passportNumber;

    @OneToOne(mappedBy = "passport")
    private Citizen citizen;

	public int getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(int passportNumber) {
		this.passportNumber = passportNumber;
	}

	public Citizen getCitizen() {
		return citizen;
	}

	public void setCitizen(Citizen citizen) {
		this.citizen = citizen;
	}

    // Getters and Setters
    
}
