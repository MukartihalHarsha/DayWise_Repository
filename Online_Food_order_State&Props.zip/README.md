# online-food-ordering-simple-cra

Minimal Create React App demo for Online Food Ordering.

## Run
1) Install deps
```
npm install
```
2) Start dev server
```
npm start
```
