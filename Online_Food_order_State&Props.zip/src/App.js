import React, { useState } from "react";
import Menu from "./Menu";
import Cart from "./Cart";
import "./App.css";

function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (item) => setCart([...cart, item]);

  return (
    <div className="App">
      <h1>Online Food Ordering</h1>
      <Menu addToCart={addToCart} />
      <Cart cart={cart} />
    </div>
  );
}

export default App;
