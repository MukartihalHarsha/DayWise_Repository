import React from "react";

function FoodCard({ item, addToCart }) {
  return (
    <div className="card">
      <h3>{item.name}</h3>
      <p>Price: ₹{item.price}</p>
      <button onClick={() => addToCart(item)}>Add to Cart</button>
    </div>
  );
}

export default FoodCard;
