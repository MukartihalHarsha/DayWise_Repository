import React from "react";
import FoodCard from "./FoodCard";

const FOOD = [
  { id: 1, name: "Pizza", price: 200 },
  { id: 2, name: "Burger", price: 100 },
  { id: 3, name: "Pasta", price: 150 },
];

function Menu({ addToCart }) {
  return (
    <div>
      <h2>Menu</h2>
      {FOOD.map((item) => (
        <FoodCard key={item.id} item={item} addToCart={addToCart} />
      ))}
    </div>
  );
}

export default Menu;
