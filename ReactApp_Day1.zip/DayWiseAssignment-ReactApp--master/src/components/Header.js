import React from 'react'

const Header = () => {
  return (
    <div>
        <h4>Header Component</h4>
    </div>
  )
}

export default Header