import React from 'react'

const Fifth = () => {
    const isAdmin = true;
  return (
    <div>
        <h2>Ternary example</h2>
        <p>{isAdmin ? "You are an Admin." : "Your are a Guest. "}</p>
    </div>
  )
}

export default Fifth