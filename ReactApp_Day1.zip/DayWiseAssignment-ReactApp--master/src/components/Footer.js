import React from 'react'

const Footer = () => {
  return (
    <div>
        <h4>Footer Component</h4>
    </div>
  )
}

export default Footer