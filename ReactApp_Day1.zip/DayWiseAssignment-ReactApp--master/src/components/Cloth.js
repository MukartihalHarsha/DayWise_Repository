import React from 'react'
import "./Cloth.css";

const Cloth = () => {
  const products = [
        { id: 101, name: "T-Shirt", description: "Cotton material", price: 499, sizes: ["S" , "M", "L", "XL"] },
        { id: 102, name: "Jeans", description: "slim fit denim", price: 1299, sizes:["M", "L", "XL"] },
        { id: 103, name: "Jacket", description: "Winter collection", price: 2499, sizes: ["L", "XL"] },
    ];
  return (
    <div className='product-container'>
        <h2 className='title'>Cloth Store Page</h2>

        {products.length === 0 ? (
        <p className="no-products">No Products Available</p>
      ) : (

        <table className='product-table'>
            <thead>
                <tr>
                    <th>Product ID</th>
                    <th>Product Name</th>
                    <th>Description</th>
                    <th>Price (&#8377;)</th>
                    <th>Available Sizes</th>
                </tr>
            </thead>
            <tbody>
                {products.map((product)=>(
                    <tr key={product.id}>
                        <td>{product.id}</td>
                        <td>{product.name}</td>
                        <td>{product.description}</td>
                        <td>{product.price}</td>
                        <td>{product.sizes.join(",")}</td>
                    </tr>
                ))}
            </tbody> 
        </table>
      )}
    </div>
  )
}

export default Cloth