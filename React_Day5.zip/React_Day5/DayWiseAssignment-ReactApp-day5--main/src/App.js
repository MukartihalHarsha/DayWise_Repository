// src/App.js
import React from "react";
import FeedbackForm from "./components/FeedbackForm";
import withValidation from "./components/withValidation";
import withAuth from "./components/withAuth";
import withLogger from "./components/withLogger";

// Compose HOCs: Auth → Validation → Logger → Form
const EnhancedFeedbackForm = withAuth(
  withValidation(
    withLogger(FeedbackForm)
  )
);

function App() {
  const handleFinalSubmit = (data) => {
    alert("✅ Feedback Submitted Successfully!");
    console.log("Final Submission Data:", data);
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-100">
      <EnhancedFeedbackForm onSubmit={handleFinalSubmit} />
    </div>
  );
}

export default App;
