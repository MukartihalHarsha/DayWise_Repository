// src/components/withValidation.js
import React from "react";

const withValidation = (WrappedComponent) => {
  return (props) => {
    const handleSubmit = (data) => {
      if (!data.comments || !data.milestone || !data.rating) {
        alert("⚠️ All fields are required!");
        return;
      }
      props.onSubmit(data);
    };

    return <WrappedComponent {...props} onSubmit={handleSubmit} />;
  };
};

export default withValidation;
