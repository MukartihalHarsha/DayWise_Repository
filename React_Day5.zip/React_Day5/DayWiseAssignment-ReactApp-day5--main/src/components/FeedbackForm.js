// src/components/FeedbackForm.js
import React, { useState } from "react";

const FeedbackForm = ({ onSubmit }) => {
  const [comments, setComments] = useState("");
  const [milestone, setMilestone] = useState("");
  const [rating, setRating] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ comments, milestone, rating });
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 border rounded-md">
      <h2 className="text-xl font-bold mb-3" >Employee Feedback Form</h2>

      <label className="block mb-2">Comments:  </label>
      <input
        type="text"
        value={comments}
        onChange={(e) => setComments(e.target.value)}
        className="border p-2 w-full mb-3"
      /><br></br>

      <label className="block mb-2">MileStone 2 Completed?  </label>
      <select
        value={milestone}
        onChange={(e) => setMilestone(e.target.value)}
        className="border p-2 w-full mb-3"
      >
        <option value="">Select</option>
        <option value="Yes">Yes</option>
        <option value="No">No</option>
      </select>
      <br></br>

      <label className="block mb-2">Training Quality (1–5):  </label>
      <select
        value={rating}
        onChange={(e) => setRating(e.target.value)}
        className="border p-2 w-full mb-3"
      >
        <option value="">Select</option>
        <option value="1">1 - Poor</option>
        <option value="2">2</option>
        <option value="3">3 - Average</option>
        <option value="4">4</option>
        <option value="5">5 - Excellent</option>
      </select>
      <br></br>

      <button
        type="submit"
        className="bg-blue-500 text-white p-2 rounded-md" content="#333"
      >
        Submit Feedback
      </button>
    </form>
  );
};

export default FeedbackForm;
