import React,{useState}from 'react'

const withAuth=(WrappedComponent)=>{
    return (props)=>{
        const isLoggedIn=props.isLoggedIn;
        if(!isLoggedIn){
            return <h2>Please Login to access Employee Portal</h2>
        }
        return <WrappedComponent {...props}/>
    }
}


const withRole=(allowedRoles)=>(WrappedComponent)=>{
    return(props)=>{
        if(!allowedRoles.includes(props.role)){
            return <h2>Access Denied: Insufficient Role</h2>
        }
        return <WrappedComponent {...props}/>
    }
}

const withLogger=(WrappedComponent)=>{
    return(props)=>{
        console.log("Logger HOC: Props Recieved",props)
        return <WrappedComponent {...props}/>
    }
}

const withTheme=(WrappedComponent)=>{
    return(props)=>{
        const themStyle=props.theme==="dark"
        ?{background:"#333",color:"#fff",padding:"20px"}
        :{background: "#f9f9f9",color:"#000", padding:"20px"}

        return (
            <div style={themStyle}>
                <WrappedComponent {...props}/>
            </div>
        )
    }
}

const withErrorBoundary=(WrappedComponent)=>{
    return class extends React.Component{
        constructor(props){
            super(props)
            this.state={hasError:false}
        }

        static getDerivedStateFromError(){
            return {hasError:true}
        }
        componentDidCatch(error,info){
            console.error("Error caught by HOC Error Boundary ",error, info)
        }
        render(){
            if(this.state.hasError){
                return <h2>Something went wrong!</h2>
            }
            return <WrappedComponent {...this.props}/>
        }
    }
}

const EmployeeDashBoard=({role})=>{
    if(!role) throw new Error("Role not found");

    return (
        <div>
        <h1>Welcome to Employee Portal</h1>
        <h3>Role: {role}</h3>
        <p>Here is your dashboard with employee details.</p>
        </div>
    )
}

const EnhancedEmployeeDashBoardn=withAuth(
    withRole(['Admin','Employee'])(withLogger(withTheme(withErrorBoundary)(EmployeeDashBoard)))
)

const EmployeeHOC=()=>{
    const [user]=useState({
      isLoggedIn:true,
      role:"Admin",
      theme:"dark"  
    })
    return(
        <div>
            <EnhancedEmployeeDashBoardn isLoggedIn={user.isLoggedIn}
            role={user.role} theme={user.theme}/>
            </div>
    )

}



export default EmployeeHOC