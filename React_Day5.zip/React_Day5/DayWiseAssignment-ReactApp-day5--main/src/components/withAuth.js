// src/components/withAuth.js
import React from "react";

const withAuth = (WrappedComponent) => {
  return (props) => {
    const isLoggedIn = true; // Simulated login check

    if (!isLoggedIn) {
      return <p>❌ Please log in to submit feedback.</p>;
    }

    return <WrappedComponent {...props} />;
  };
};

export default withAuth;
