// src/components/withLogger.js
import React from "react";

const withLogger = (WrappedComponent) => {
  return (props) => {
    const handleSubmit = (data) => {
      console.log("📊 Feedback Submitted:", data);
      props.onSubmit(data);
    };

    return <WrappedComponent {...props} onSubmit={handleSubmit} />;
  };
};

export default withLogger;
